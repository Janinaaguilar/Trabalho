/*
 * Classe responsável pelo cálculo de Fibonacci e controle da barra de progresso e das threads
 */
package pacote;

import javax.swing.JOptionPane;
import javax.swing.SwingWorker;

/**
 *
 * @author Janina
 */
public class FibonacciWorker extends SwingWorker {

    private final long n;

    public FibonacciWorker(long n) {
        this.n = n;
    }

    protected Long doInBackground() throws Exception {
        return calcularSeqFibonacci();
    }

    protected void done() {
        if (isCancelled()) {
            return;
        }
        try {
           JOptionPane.showMessageDialog(null, get());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    protected long calcularSeqFibonacci() {
        long seq = 0;
        long fibonacci = 0;
        for (int i=1; i<=n && !isCancelled(); i++) {
            fibonacci = calcFibonacci(i);
            seq = fibonacci;
            publish(fibonacci);
            setProgress(Math.round((float)i/n*100));
        }
        //setProgress(100);
        if(isCancelled())
            setProgress(0);//se cancelado a barra de progresso volta para zero
        return fibonacci;
    }

    private long calcFibonacci(int i) {
        assert (i >= 1);
        if (i == 1 || i == 2) {
            return 1;
        } else {
            return calcFibonacci(i - 1) + calcFibonacci(i - 2);
        }
    }
}
