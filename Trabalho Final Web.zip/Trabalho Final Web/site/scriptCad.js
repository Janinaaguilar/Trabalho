var form = document.getElementById("formCad");
if (form.addEventListener) {                   
    form.addEventListener("submit", validaCadastroP);
} else if (form.attachEvent) {                  
    form.attachEvent("onsubmit", validaCadastroP);
}
 
function validaCadastroP(evt){
	var vencimento = document.getElementById('venc');
	var plano = document.getElementById('plano');
	var login = document.getElementById('q');
	var senha = document.getElementById('senha');
	var nomeC = document.getElementById('nome');
	var endEmail= document.getElementById('email');
	var cpfCnpj = document.getElementById('cpf_cnpj');
	var rg = document.getElementById('rg');
	var dataNasc = document.getElementById('cli_data_nasc');
	var telefone = document.getElementById('telefone');
	var celular = document.getElementById('celular');
	var promocod = document.getElementById('promocod');
	var cep = document.getElementById('cep');
	var endereco = document.getElementById('endereco');
	var numeroC = document.getElementById('numero');
	var complemento = document.getElementById('complemento');
	var bairro = document.getElementById('bairro');
	var cidade = document.getElementById('cidade');
	var estado = document.getElementById('estado');
	var captchay = document.getElementById('captchay');
	var codigo = document.getElementById('codigo');
	var termo = document.getElementById('aceitou');


	var filtro = /^([\w-]+(?:\.[\w-]+)*)@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$/i;
	var contErro = 0;
 
 
	/* Validação do campo vencimento */
	caixa_venc = document.querySelector('.msg-venc');
	if(vencimento.value == ""){
		caixa_venc.innerHTML = "Por favor, selecione o dia de vencimento.";
		caixa_venc.style.display = 'block';
		contErro += 1;
	}else{
		caixa_venc.style.display = 'none';
	}

	/* Validação do campo de planos */
	caixa_plano = document.querySelector('.msg-plano');
	if(plano.value == ""){
		caixa_plano .innerHTML = "Por favor, selecione o plano.";
		caixa_plano .style.display = 'block';
		contErro += 1;
	}else{
		caixa_plano .style.display = 'none';
	}
	/* Validação do campo de login */
	caixa_log = document.querySelector('.msg-log');
	if(login.value == ""){
		caixa_log .innerHTML = "Por favor, preencha o campo de login.";
		caixa_log .style.display = 'block';
		contErro += 1;
	}else{
		caixa_log .style.display = 'none';
	}
	/* Validação do campo de senha */
	caixa_senha = document.querySelector('.msg-senha');
	if(senha.value == ""){
		caixa_senha .innerHTML = "Por favor, preencha o campo de senha.";
		caixa_senha .style.display = 'block';
		contErro += 1;
	}else{
		caixa_senha .style.display = 'none';
	}
	/* Validação do campo de nome */
	caixa_nomeC = document.querySelector('.msg-nome');
	if(nomeC.value == ""){
		caixa_nomeC .innerHTML = "Por favor, preencha o campo de nome.";
		caixa_nomeC .style.display = 'block';
		contErro += 1;
	}else{
		caixa_nomeC .style.display = 'none';
	}
	/* Validação do campo de email */
	caixa_email = document.querySelector('.msg-email');
	if(endEmail.value == ""){
		caixa_email.innerHTML = "Por favor, preencha o e-mail.";
		caixa_email.style.display = 'block';
		contErro += 1;
	}else if(filtro.test(email.value)){
		caixa_email.style.display = 'none';
	}else{
		caixa_email.innerHTML = "Formato do e-mail inválido.";
		caixa_email.style.display = 'block';
		contErro += 1;
	}	
	/* Validação do campo de cpf/cnpj */
	caixa_cpf = document.querySelector('.msg-cpf');
	if(endEmail.value == ""){
		caixa_cpf.innerHTML = "Por favor, preencha o campo de CPF/CNPJ.";
		caixa_cpf.style.display = 'block';
		contErro += 1;
	}else{
		caixa_cpf.style.display = 'none';
	}

	/* Validação do campo de identidade*/
	caixa_identidade = document.querySelector('.msg-identidade');
	if(rg.value == ""){
		caixa_identidade.innerHTML = "Por favor, preencha o campo de identidade.";
		caixa_identidade.style.display = 'block';
		contErro += 1;
	}else{
		caixa_identidade.style.display = 'none';
	}

	/* Validação do campo de nascimento
	caixa_nascimento = document.querySelector('.msg-nascimento');
	if(dataNasc.value == ""){
		caixa_nascimento.innerHTML = "Por favor, preencha o campo de nascimento.";
		caixa_nascimento.style.display = 'block';
		contErro += 1;
	}else{
		caixa_nascimento.style.display = 'none';
	}

	/* Validação do campo de telefone*/
	caixa_telefone = document.querySelector('.msg-fone');
	if(telefone.value == ""){
		caixa_telefone.innerHTML = "Por favor, preencha o campo de telefone.";
		caixa_telefone.style.display = 'block';
		contErro += 1;
	}else{
		caixa_telefone.style.display = 'none';
	}

	/* Validação do campo de celular
	caixa_celular = document.querySelector('.msg-celular');
	if(celular.value == ""){
		caixa_celular.innerHTML = "Por favor, preencha o campo de celular.";
		caixa_celular.style.display = 'block';
		contErro += 1;
	}else{
		caixa_celular.style.display = 'none';
	}

	/* Validação do campo de codigo promoção
	caixa_promocod = document.querySelector('.msg-codP');
	if(promocod.value == ""){
		caixa_promocod.innerHTML = "Por favor, preencha o campo de codigo.";
		caixa_promocod.style.display = 'block';
		contErro += 1;
	}else{
		caixa_promocod.style.display = 'none';
	}

	/* Validação do campo de cep*/
	caixa_cep = document.querySelector('.msg-cep');
	if(cep.value == ""){
		caixa_cep.innerHTML = "Por favor, preencha o campo de CEP.";
		caixa_cep.style.display = 'block';
		contErro += 1;
	}else{
		caixa_cep.style.display = 'none';
	}

	/* Validação do campo de endereco*/
	caixa_end = document.querySelector('.msg-endereco');
	if(endereco.value == ""){
		caixa_end.innerHTML = "Por favor, preencha o campo de logadouro.";
		caixa_end.style.display = 'block';
		contErro += 1;
	}else{
		caixa_end.style.display = 'none';
	}

	/* Validação do campo de numero da Casa*/
	caixa_numCasa = document.querySelector('.msg-numCasa');
	if(numeroC.value == ""){
		caixa_numCasa.innerHTML = "Por favor, preencha o número.";
		caixa_numCasa.style.display = 'block';
		contErro += 1;
	}else{
		caixa_numCasa.style.display = 'none';
	}

	/* Validação do campo de complemento
	caixa_complemento = document.querySelector('.msg-complemento');
	if(complemento.value == ""){
		caixa_complemento.innerHTML = "Por favor, preencha o complemento.";
		caixa_complemento.style.display = 'block';
		contErro += 1;
	}else{
		caixa_complemento.style.display = 'none';
	}
	/* Validação do campo de bairro*/
	caixa_bairro = document.querySelector('.msg-bairro');
	if(bairro.value == ""){
		caixa_bairro.innerHTML = "Por favor, preencha o bairro.";
		caixa_bairro.style.display = 'block';
		contErro += 1;
	}else{
		caixa_bairro.style.display = 'none';
	}

	/* Validação do campo de cidade*/
	caixa_cidade = document.querySelector('.msg-cidade');
	if(bairro.value == ""){
		caixa_cidade.innerHTML = "Por favor, preencha o cidade.";
		caixa_cidade.style.display = 'block';
		contErro += 1;
	}else{
		caixa_cidade.style.display = 'none';
	}
	/* Validação do campo de captchay */
	caixa_captchay = document.querySelector('.msg-caracter');
	if(captchay.value == ""){
		caixa_captchay.innerHTML = "Por favor, preencha o campo verificação.";
		caixa_captchay.style.display = 'block';
		contErro += 1;
	}else{
		caixa_captchay.style.display = 'none';
		}
	/*Validação do campo de codigo*/
	caixa_codigo = document.querySelector('.msg-codConfirm');
	if(codigo.value == ""){
		caixa_codigo.innerHTML = "Por favor, preencha o campo de codigo.";
		caixa_codigo.style.display = 'block';
		contErro += 1;
	}else{
		caixa_codigo.style.display = 'none';
	}
	/*Validação do campo de termo de compromisso*/
	caixa_termo  = document.querySelector('.msg-termo');
	if(termo.value == ""){
		caixa_termo.innerHTML = "Por favor, preencha o campo de contrato.";
		caixa_termo.style.display = 'block';
		contErro += 1;
	}else{
		caixa_termo.style.display = 'none';
	}
	if(contErro > 0){
		evt.preventDefault();
	}
}