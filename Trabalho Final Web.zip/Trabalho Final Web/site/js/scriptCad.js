var form = document.getElementById("formCad");
if (form.addEventListener) {                   
    form.addEventListener("submit", validaCadastroP);
    form.addEventListener("submit", VerificaCPF);
    form.addEventListener("submit", checa_cnpj);
    
} else if (form.attachEvent) {                  
    form.attachEvent("onsubmit", validaCadastroP);
}
 
function validaCadastroP(evt){
	var vencimento = document.getElementById('venc');
	var plano = document.getElementById('plano');
	var login = document.getElementById('q');
	var senha = document.getElementById('senha');
	var nomeC = document.getElementById('nome');
	var endEmail= document.getElementById('email');
	var cpfCnpj = document.getElementById('cpf_cnpj');
	var rg = document.getElementById('rg');
	var dataNasc = document.getElementById('data_nasc');
	var telefone = document.getElementById('telefone');
	var celular = document.getElementById('celular');
	var promocod = document.getElementById('promocod');
	var cep = document.getElementById('cep');
	var endereco = document.getElementById('endereco');
	var numeroC = document.getElementById('numero');
	var complemento = document.getElementById('complemento');
	var bairro = document.getElementById('bairro');
	var cidade = document.getElementById('cidade');
	var estado = document.getElementById('estado');
	var captchay = document.getElementById('captchay');
	var codigo = document.getElementById('codigo');
	var termo = document.getElementById('aceitou');


	var filtro = /^([\w-]+(?:\.[\w-]+)*)@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$/i;
	var contErro = 0;
 
 
	/* Validação do campo vencimento */
	caixa_venc = document.querySelector('.msg-venc');
	if(vencimento.value == ""){
		caixa_venc.innerHTML = "Por favor, selecione o dia de vencimento.";
		caixa_venc.style.display = 'block';
		contErro += 1;
	}else{
		caixa_venc.style.display = 'none';
	}

	/* Validação do campo de planos */
	caixa_plano = document.querySelector('.msg-plano');
	if(plano.value == ""){
		caixa_plano .innerHTML = "Por favor, selecione o plano.";
		caixa_plano .style.display = 'block';
		contErro += 1;
	}else{
		caixa_plano .style.display = 'none';
	}
	/* Validação do campo de login */
	caixa_log = document.querySelector('.msg-log');
	if(login.value == ""){
		caixa_log .innerHTML = "Por favor, preencha o campo de login.";
		caixa_log .style.display = 'block';
		contErro += 1;
	}else{
		caixa_log .style.display = 'none';
	}
	/* Validação do campo de senha */
	caixa_senha = document.querySelector('.msg-senha');
	if(senha.value == ""){
		caixa_senha .innerHTML = "Por favor, preencha o campo de senha.";
		caixa_senha .style.display = 'block';
		contErro += 1;
	}else if(senha.value.length <6){
		caixa_senha.innerHTML = "Por favor preencher senha com no mínimo 6 caracteres.";
		caixa_senha.style.display = 'block';
		contErro +=1;
	}else{
		caixa_senha .style.display = 'none';
	}
	/* Validação do campo de nome */
	caixa_nomeC = document.querySelector('.msg-nome');
	if(nomeC.value == ""){
		caixa_nomeC .innerHTML = "Por favor, preencha o campo de nome.";
		caixa_nomeC .style.display = 'block';
		contErro += 1;
	}else{
		caixa_nomeC .style.display = 'none';
	}
	/* Validação do campo de email */
	caixa_email = document.querySelector('.msg-email');
	if(endEmail.value == ""){
		caixa_email.innerHTML = "Por favor, preencha o e-mail.";
		caixa_email.style.display = 'block';
		contErro += 1;
	}else if(filtro.test(email.value)){
		caixa_email.style.display = 'none';
	}else{
		caixa_email.innerHTML = "Formato do e-mail inválido.";
		caixa_email.style.display = 'block';
		contErro += 1;
	}	
	/* Validação do campo de cpf/cnpj */
	caixa_cpf = document.querySelector('.msg-cpf');
	if(endEmail.value == ""){
		caixa_cpf.innerHTML = "Por favor, preencha o campo de CPF/CNPJ.";
		caixa_cpf.style.display = 'block';
		contErro += 1;
	}else{
		caixa_cpf.style.display = 'none';
	}

	/* Validação do campo de identidade*/
	caixa_identidade = document.querySelector('.msg-identidade');
	if(rg.value == ""){
		caixa_identidade.innerHTML = "Por favor, preencha o campo de identidade.";
		caixa_identidade.style.display = 'block';
		contErro += 1;
	}else{
		caixa_identidade.style.display = 'none';
	}



	/* Validação do campo de telefone*/
	caixa_telefone = document.querySelector('.msg-fone');
	if(telefone.value == ""){
		caixa_telefone.innerHTML = "Por favor, preencha o campo de telefone.";
		caixa_telefone.style.display = 'block';
		contErro += 1;
	}else{
		caixa_telefone.style.display = 'none';
	}

	/* Validação do campo de celular*/
	caixa_celular = document.querySelector('.msg-celular');
	if(celular.value == ""){
		caixa_celular.innerHTML = "Por favor, preencha o campo de celular.";
		caixa_celular.style.display = 'block';
		contErro += 1;
	}else{
		caixa_celular.style.display = 'none';
	}

	/* Validação do campo de cep*/
	caixa_cep = document.querySelector('.msg-cep');
	if(cep.value == ""){
		caixa_cep.innerHTML = "Por favor, preencha o campo de CEP.";
		caixa_cep.style.display = 'block';
		contErro += 1;
	}else{
		caixa_cep.style.display = 'none';
	}

	/* Validação do campo de endereco*/
	caixa_end = document.querySelector('.msg-endereco');
	if(endereco.value == ""){
		caixa_end.innerHTML = "Por favor, preencha o campo de logadouro.";
		caixa_end.style.display = 'block';
		contErro += 1;
	}else{
		caixa_end.style.display = 'none';
	}

	/* Validação do campo de numero da Casa*/
	caixa_numCasa = document.querySelector('.msg-numCasa');
	if(numeroC.value == ""){
		caixa_numCasa.innerHTML = "Por favor, preencha o número.";
		caixa_numCasa.style.display = 'block';
		contErro += 1;
	}else{
		caixa_numCasa.style.display = 'none';
	}

	/* Validação do campo de bairro*/
	caixa_bairro = document.querySelector('.msg-bairro');
	if(bairro.value == ""){
		caixa_bairro.innerHTML = "Por favor, preencha o bairro.";
		caixa_bairro.style.display = 'block';
		contErro += 1;
	}else{
		caixa_bairro.style.display = 'none';
	}

	/* Validação do campo de cidade*/
	caixa_cidade = document.querySelector('.msg-cidade');
	if(bairro.value == ""){
		caixa_cidade.innerHTML = "Por favor, preencha o cidade.";
		caixa_cidade.style.display = 'block';
		contErro += 1;
	}else{
		caixa_cidade.style.display = 'none';
	}
	/* Validação do campo de captchay */
	caixa_captchay = document.querySelector('.msg-caracter');
	if(captchay.value == ""){
		caixa_captchay.innerHTML = "Por favor, preencha o campo verificação.";
		caixa_captchay.style.display = 'block';
		contErro += 1;
	}else{
		caixa_captchay.style.display = 'none';
		}
	/*Validação do campo de codigo*/
	caixa_codigo = document.querySelector('.msg-codConfirm');
	if(codigo.value == ""){
		caixa_codigo.innerHTML = "Por favor, preencha o campo de codigo.";
		caixa_codigo.style.display = 'block';
		contErro += 1;
	}else{
		caixa_codigo.style.display = 'none';
	}
	/*Validação do campo de termo de compromisso*/
	caixa_termo  = document.querySelector('.msg-termo');
	if(termo.value == ""){
		caixa_termo.innerHTML = "Por favor, preencha o campo de contrato.";
		caixa_termo.style.display = 'block';
		contErro += 1;
	}else{
		caixa_termo.style.display = 'none';
	}
	if(contErro > 0){
		evt.preventDefault();
	}
}

//Função para checar a validade de do cpf
function VerificaCPF () {
if (vercpf(document.form.cpf_cnpj.value)) 
{document.form.submit();}else 
{errors="1";if (errors) alert('CPF NÃO VÁLIDO');
document.retorno = (errors == '');}}
function vercpf (cpf) 
{if (cpf.length != 11 || cpf == "00000000000" || cpf == "11111111111" || cpf == "22222222222" || cpf == "33333333333" || cpf == "44444444444" || cpf == "55555555555" || cpf == "66666666666" || cpf == "77777777777" || cpf == "88888888888" || cpf == "99999999999")
return false;
add = 0;
for (i=0; i < 9; i ++)
add += parseInt(cpf.charAt(i)) * (10 - i);
rev = 11 - (add % 11);
if (rev == 10 || rev == 11)
rev = 0;
if (rev != parseInt(cpf.charAt(9)))
return false;
add = 0;
for (i = 0; i < 10; i ++)
add += parseInt(cpf.charAt(i)) * (11 - i);
rev = 11 - (add % 11);
if (rev == 10 || rev == 11)
rev = 0;
if (rev != parseInt(cpf.charAt(10)))
return false;
alert('O CPF INFORMADO É VÁLIDO.');return true;}


//Função para checar do CNPJ
function checa_cnpj(s) {
	var mensagem = "informe corretamente o número do CNPJ"
	var msg = "";
	var y;
	var c = s.substr(0, 12);
	var dv = s.substr(12, 2);
	var d1 = 0;
	for (y = 0; y < 12; y++) {
		d1 += c.charAt(11 - y) * (2 + (y % 8));
	}
	if (d1 == 0) msg = mensagem;
	d1 = 11 - (d1 % 11);
	if (d1 > 9) d1 = 0;
	if (dv.charAt(0) != d1) msg = mensagem;
	d1 *= 2;
	for (y = 0; y < 12; y++) {
		d1 += c.charAt(11 - y) * (2 + ((y + 1) % 8));
	}
	d1 = 11 - (d1 % 11);
	if (d1 > 9) d1 = 0;
	if (dv.charAt(1) != d1) msg = mensagem;
	return msg;
}

/*fu~ção para validar CEP
função  ValidaCep (cep) {
        exp =/\ d {2}\.\ d {3} \-\ d {3} / 
        se (!exp.teste (cep.value))
                alerta ('Numero de Cep Invalido!');               
}
function nu(campo){
var digits="0123456789"
var campo_temp 
for (var i=0;i<campo.value.length;i++){
campo_temp=campo.value.substring(i,i+1) 
if (digits.indexOf(campo_temp)==-1){
campo.value = campo.value.substring(0,i);
break;
}
}
}
 
function ValRG(numero){
 var numero = numero.split("");
 tamanho = numero.length;
 vetor = new Array(tamanho);
 
if(tamanho>=1)
{
 vetor[0] = parseInt(numero[0]) * 2; 
}
if(tamanho>=2){
 vetor[1] = parseInt(numero[1]) * 3; 
}
if(tamanho>=3){
 vetor[2] = parseInt(numero[2]) * 4; 
}
if(tamanho>=4){
 vetor[3] = parseInt(numero[3]) * 5; 
}
if(tamanho>=5){
 vetor[4] = parseInt(numero[4]) * 6; 
}
if(tamanho>=6){
 vetor[5] = parseInt(numero[5]) * 7; 
}
if(tamanho>=7){
 vetor[6] = parseInt(numero[6]) * 8; 
}
if(tamanho>=8){
 vetor[7] = parseInt(numero[7]) * 9; 
}
if(tamanho>=9){
 vetor[8] = parseInt(numero[8]) * 100; 
}
 
 total = 0;
 
if(tamanho>=1){
 total += vetor[0];
}
if(tamanho>=2){
 total += vetor[1]; 
}
if(tamanho>=3){
 total += vetor[2]; 
}
if(tamanho>=4){
 total += vetor[3]; 
}
if(tamanho>=5){
 total += vetor[4]; 
}
if(tamanho>=6){
 total += vetor[5]; 
}
if(tamanho>=7){
 total += vetor[6];
}
if(tamanho>=8){
 total += vetor[7]; 
}
if(tamanho>=9){
 total += vetor[8]; 
}
 
 resto = total % 11;
if(resto!=0){
document.getElementById('#rg').innerHTML="RG Inválido!";
}
else{
document.getElementById('#rg').innerHTML="RG Válido!";
}
}*/