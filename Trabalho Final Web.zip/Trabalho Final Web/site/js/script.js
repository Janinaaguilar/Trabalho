var form1 = document.getElementById("central_login");
if (form1.addEventListener) {                   
    form1.addEventListener("submit", validaCadastroC);
} else if (form.attachEvent) {                  
    form1.attachEvent("onsubmit", validaCadastroC);
}
 
function validaCadastroC(evt){
	var login = document.getElementById('login');
	var cpf = document.getElementById('cpf');
	var contErro = 0;


	/* Validação do campo login */
	caixa_login = document.querySelector('.msg-login');
	if(login.value == ""){
		caixa_login.innerHTML = "Por favor, digite seu login.";
		caixa_login.style.display = 'block';
		contErro += 1;
	}else{
		caixa_login.style.display = 'none';
	}
	if(contErro > 0){
			evt.preventDefault();
		}
		/* Validação do campo CPF/CNPJ */
	caixa_cpf = document.querySelector('.msg-cpf');
	if(cpf.value == ""){
		caixa_cpf.innerHTML = "Por favor, digite seu CPF/CNPJ.";
		caixa_cpf.style.display = 'block';
		contErro += 1;
	}else{
		caixa_cpf.style.display = 'none';
	}

}

//Função para checar a validade de do cpf
function VerificaCPF () {
if (vercpf(document.form.cpf_cnpj.value)) 
{document.form.submit();}else 
{errors="1";if (errors) alert('CPF NÃO VÁLIDO');
document.retorno = (errors == '');}}
function vercpf (cpf) 
{if (cpf.length != 11 || cpf == "00000000000" || cpf == "11111111111" || cpf == "22222222222" || cpf == "33333333333" || cpf == "44444444444" || cpf == "55555555555" || cpf == "66666666666" || cpf == "77777777777" || cpf == "88888888888" || cpf == "99999999999")
return false;
add = 0;
for (i=0; i < 9; i ++)
add += parseInt(cpf.charAt(i)) * (10 - i);
rev = 11 - (add % 11);
if (rev == 10 || rev == 11)
rev = 0;
if (rev != parseInt(cpf.charAt(9)))
return false;
add = 0;
for (i = 0; i < 10; i ++)
add += parseInt(cpf.charAt(i)) * (11 - i);
rev = 11 - (add % 11);
if (rev == 10 || rev == 11)
rev = 0;
if (rev != parseInt(cpf.charAt(10)))
return false;
alert('O CPF INFORMADO É VÁLIDO.');return true;}


//Função para checar do CNPJ
function checa_cnpj(s) {
	var mensagem = "informe corretamente o número do CNPJ"
	var msg = "";
	var y;
	var c = s.substr(0, 12);
	var dv = s.substr(12, 2);
	var d1 = 0;
	for (y = 0; y < 12; y++) {
		d1 += c.charAt(11 - y) * (2 + (y % 8));
	}
	if (d1 == 0) msg = mensagem;
	d1 = 11 - (d1 % 11);
	if (d1 > 9) d1 = 0;
	if (dv.charAt(0) != d1) msg = mensagem;
	d1 *= 2;
	for (y = 0; y < 12; y++) {
		d1 += c.charAt(11 - y) * (2 + ((y + 1) % 8));
	}
	d1 = 11 - (d1 % 11);
	if (d1 > 9) d1 = 0;
	if (dv.charAt(1) != d1) msg = mensagem;
	return msg;
}

