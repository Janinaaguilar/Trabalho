var form1 = document.getElementById("central_login");
if (form1.addEventListener) {                   
    form1.addEventListener("submit", validaCadastroC);
} else if (form.attachEvent) {                  
    form1.attachEvent("onsubmit", validaCadastroC);
}
 
function validaCadastroC(evt){
	var login = document.getElementById('login');
	var cpf = document.getElementById('cpf');
	var contErro = 0;


	/* Validação do campo login */
	caixa_login = document.querySelector('.msg-login');
	if(login.value == ""){
		caixa_login.innerHTML = "Por favor, digite seu login.";
		caixa_login.style.display = 'block';
		contErro += 1;
	}else{
		caixa_login.style.display = 'none';
	}

	/* Validação do campo CPF/CNPJ */
	caixa_cpf = document.querySelector('.msg-cpf');
	if(cpf.value == ""){
		caixa_cpf.innerHTML = "Por favor, digite seu CPF/CNPJ.";
		caixa_cpf.style.display = 'block';
		contErro += 1;
	}else{
		caixa_cpf.style.display = 'none';
	}

	if(contErro > 0){
		evt.preventDefault();
	}

}

var form = document.getElementById("form");
if (form.addEventListener) {                   
    form.addEventListener("submit",validaCadastro);
} else if (form.attachEvent) {                  
    form.attachEvent("onsubmit",validaCadastro);
}
 
function validaCadastro(evt){
	var nome = document.getElementById('nome');
	var email = document.getElementById('email');
	var telefone = document.getElementById('telefone');
	var assunto = document.getElementById('assunto');
	var msg = document.getElementById('msg');
	var filtro = /^([\w-]+(?:\.[\w-]+)*)@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$/i;
	var contErro = 0;
 
 
	/* Validação do campo nome */
	caixa_nome = document.querySelector('.msg-nome');
	if(nome.value == ""){
		caixa_nome.innerHTML = "Por favor, preencha o nome.";
		caixa_nome.style.display = 'block';
		contErro += 1;
	}else{
		caixa_nome.style.display = 'none';
	}
	/* Validação do campo email */
	caixa_email = document.querySelector('.msg-email');
	if(email.value == ""){
		caixa_email.innerHTML = "Por favor, preencha o e-mail.";
		caixa_email.style.display = 'block';
		contErro += 1;
	}else if(filtro.test(email.value)){
		caixa_email.style.display = 'none';
	}else{
		caixa_email.innerHTML = "Formato do e-mail inválido.";
		caixa_email.style.display = 'block';
		contErro += 1;
	}	
 	/* Validação do campo telefone */
	caixa_fone = document.querySelector('.msg-fone');
	if(telefone.value == ""){
		caixa_fone.innerHTML = "Por favor, preencha o telefone.";
		caixa_fone.style.display = 'block';
		contErro += 1;
	}else{
		caixa_fone.style.display = 'none';
	}

	/* Validação do campo assunto */
	caixa_assunto = document.querySelector('.msg-assunto');
	if(assunto.value == ""){
		caixa_assunto.innerHTML = "Por favor, preencha o assunto.";
		caixa_assunto.style.display = 'block';
		contErro += 1;
	}else{
		caixa_assunto.style.display = 'none';
	}
	/* Validação do campo mensagem */
	caixa_msg = document.querySelector('.msg-msg');
	if(msg.value == ""){
		caixa_msg.innerHTML = "Por favor, digite sua mensagem.";
		caixa_msg.style.display = 'block';
		contErro += 1;
	}else{
		caixa_msg.style.display = 'none';
	}
	if(contErro > 0){
		evt.preventDefault();
	}
}


