var form1 = document.getElementById("EsqueciSenha");
if (form1.addEventListener) {                   
    form1.addEventListener("submit", validaCadastro);
} else if (form.attachEvent) {                  
    form1.attachEvent("onsubmit", validaCadastro);
}
 
function validaCadastro(evt){
	var cpf = document.getElementById('txt_cpf');
	var contErro = 0;

	/* Validação do campo Login/CPF*/
	caixa_cpf = document.querySelector('.msg-cpf');
	if(cpf.value == ""){
		caixa_cpf.innerHTML = "Por favor, digite seu login ou CPF.";
		caixa_cpf.style.display = 'block';
		contErro += 1;
	}else{
		caixa_cpf.style.display = 'none';
	}

	if(contErro > 0){
		evt.preventDefault();
	}

}
