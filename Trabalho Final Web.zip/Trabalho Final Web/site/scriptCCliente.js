var form1 = document.getElementById("central_login");
if (form1.addEventListener) {                   
    form1.addEventListener("submit", validaCadastroC);
} else if (form.attachEvent) {                  
    form1.attachEvent("onsubmit", validaCadastroC);
}
 
function validaCadastroC(evt){
	var login = document.getElementById('login');
	var cpf = document.getElementById('cpf');
	var contErro = 0;


	/* Validação do campo login */
	caixa_login = document.querySelector('.msg-login');
	if(login.value == ""){
		caixa_login.innerHTML = "Por favor, digite seu login.";
		caixa_login.style.display = 'block';
		contErro += 1;
	}else{
		caixa_login.style.display = 'none';
	}

	/* Validação do campo CPF/CNPJ */
	caixa_cpf = document.querySelector('.msg-cpf');
	if(cpf.value == ""){
		caixa_cpf.innerHTML = "Por favor, digite seu CPF/CNPJ.";
		caixa_cpf.style.display = 'block';
		contErro += 1;
	}else{
		caixa_cpf.style.display = 'none';
	}

	if(contErro > 0){
		evt.preventDefault();
	}

}
