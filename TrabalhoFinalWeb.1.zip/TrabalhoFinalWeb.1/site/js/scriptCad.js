var form = document.getElementById("formCad");
if (form.addEventListener) {                   
	form.addEventListener("submit", validaCadastroP);  
} else if (form.attachEvent) {                  
	form.attachEvent("onsubmit", validaCadastroP);
}

function validaCadastroP(evt){
	var vencimento = document.getElementById('venc');
	var plano = document.getElementById('plano');
	var login = document.getElementById('q');
	var senha = document.getElementById('senha');
	var nomeC = document.getElementById('nome');
	var endEmail= document.getElementById('email');
	var cpfCnpj = document.getElementById('cpf_cnpj');
	var dataNasc = document.getElementById('data_nasc');
	var celular = document.getElementById('celular');
	var cep = document.getElementById('cep');
	var endereco = document.getElementById('endereco');
	var numeroC = document.getElementById('numero');
	var complemento = document.getElementById('complemento');
	var bairro = document.getElementById('bairro');
	var cidade = document.getElementById('cidade');
	var estado = document.getElementById('estado');
	var termo = document.getElementById('aceitou');


	var filtro = /^([\w-]+(?:\.[\w-]+)*)@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$/i;
	var contErro = 0;


	/* Validação do campo vencimento */
	caixa_venc = document.querySelector('.msg-venc');
	if(vencimento.value == ""){
		caixa_venc.innerHTML = "Por favor, selecione o dia de vencimento.";
		caixa_venc.style.display = 'block';
		contErro += 1;
	}else{
		caixa_venc.style.display = 'none';
	}

	/* Validação do campo de planos */
	caixa_plano = document.querySelector('.msg-plano');
	if(plano.value == ""){
		caixa_plano .innerHTML = "Por favor, selecione o plano.";
		caixa_plano .style.display = 'block';
		contErro += 1;
	}else{
		caixa_plano .style.display = 'none';
	}
	/* Validação do campo de login */
	caixa_log = document.querySelector('.msg-log');
	if(login.value == ""){
		caixa_log .innerHTML = "Por favor, preencha o campo de login.";
		caixa_log .style.display = 'block';
		contErro += 1;
	}else{
		caixa_log .style.display = 'none';
	}
	/* Validação do campo de senha */
	caixa_senha = document.querySelector('.msg-senha');
	if(senha.value == ""){
		caixa_senha .innerHTML = "Por favor, preencha o campo de senha.";
		caixa_senha .style.display = 'block';
		contErro += 1;
	}else if(senha.value.length <6){
		caixa_senha.innerHTML = "Por favor preencher senha com no mínimo 6 caracteres.";
		caixa_senha.style.display = 'block';
		contErro +=1;
	}else{
		caixa_senha .style.display = 'none';
	}
	/* Validação do campo de nome */
	caixa_nomeC = document.querySelector('.msg-nome');
	if(nomeC.value == ""){
		caixa_nomeC .innerHTML = "Por favor, preencha o campo de nome.";
		caixa_nomeC .style.display = 'block';
		contErro += 1;
	}else{
		caixa_nomeC .style.display = 'none';
	}
	/* Validação do campo de email */
	caixa_email = document.querySelector('.msg-email');
	if(endEmail.value == ""){
		caixa_email.innerHTML = "Por favor, preencha o e-mail.";
		caixa_email.style.display = 'block';
		contErro += 1;
	}else if(filtro.test(email.value)){
		caixa_email.style.display = 'none';
	}else{
		caixa_email.innerHTML = "Formato do e-mail inválido.";
		caixa_email.style.display = 'block';
		contErro += 1;
	}	
	/* Validação do campo de cpf/cnpj */
	caixa_cpf = document.querySelector('.msg-cpf');
	if(endEmail.value == ""){
		caixa_cpf.innerHTML = "Por favor, preencha o campo de CPF/CNPJ.";
		caixa_cpf.style.display = 'block';
		contErro += 1;
	}else{
		caixa_cpf.style.display = 'none';
	}

	/* Validação do campo de celular*/
	caixa_celular = document.querySelector('.msg-celular');
	if(celular.value == ""){
		caixa_celular.innerHTML = "Por favor, preencha o campo de celular.";
		caixa_celular.style.display = 'block';
		contErro += 1;
	}else{
		caixa_celular.style.display = 'none';
	}

	/* Validação do campo de cep*/
	caixa_cep = document.querySelector('.msg-cep');
	if(cep.value == ""){
		caixa_cep.innerHTML = "Por favor, preencha o campo de CEP.";
		caixa_cep.style.display = 'block';
		contErro += 1;
	}else{
		caixa_cep.style.display = 'none';
	}

	/* Validação do campo de endereco*/
	caixa_end = document.querySelector('.msg-endereco');
	if(endereco.value == ""){
		caixa_end.innerHTML = "Por favor, preencha o campo de logadouro.";
		caixa_end.style.display = 'block';
		contErro += 1;
	}else{
		caixa_end.style.display = 'none';
	}

	/* Validação do campo de numero da Casa*/
	caixa_numCasa = document.querySelector('.msg-numCasa');
	if(numeroC.value == ""){
		caixa_numCasa.innerHTML = "Por favor, preencha o número.";
		caixa_numCasa.style.display = 'block';
		contErro += 1;
	}else{
		caixa_numCasa.style.display = 'none';
	}

	/* Validação do campo de bairro*/
	caixa_bairro = document.querySelector('.msg-bairro');
	if(bairro.value == ""){
		caixa_bairro.innerHTML = "Por favor, preencha o bairro.";
		caixa_bairro.style.display = 'block';
		contErro += 1;
	}else{
		caixa_bairro.style.display = 'none';
	}

	/* Validação do campo de cidade*/
	caixa_cidade = document.querySelector('.msg-cidade');
	if(bairro.value == ""){
		caixa_cidade.innerHTML = "Por favor, preencha o cidade.";
		caixa_cidade.style.display = 'block';
		contErro += 1;
	}else{
		caixa_cidade.style.display = 'none';
	}
	/*Validação do campo de termo de compromisso*/
	caixa_termo  = document.querySelector('.msg-termo');
	if(termo.checked == ""){
		caixa_termo.innerHTML = "Por favor, marque a opção de aceitação do contrato.";
		caixa_termo.style.display = 'block';
		contErro += 1;
	}else{
		caixa_termo.style.display = 'none';
	}
	if(contErro > 0){
		evt.preventDefault();
	}
}

// Função principal de validação
function validar(obj) { // recebe um objeto
	var s = (obj.value).replace(/\D/g,'');
	var tam=(s).length; // removendo os caracteres não numéricos
	if (!(tam==11 || tam==14)){ // validando o tamanho
		alert("Não é um CPF ou um CNPJ válido!" ); // tamanho inválido
		return false;
	}
	
// se for CPF
if (tam==11 ){
		if (!validaCPF(s)){ // chama a função que valida o CPF
			alert("Não é um CPF válido!" );
			return false;
		}
		alert(" É um CPF válido!" ); // se quiser mostrar que validou		
		obj.value=maskCPF(s);	// se validou o CPF mascaramos corretamente
		return true;
	}
	
// se for CNPJ			
if (tam==14){
		if(!validaCNPJ(s)){ // chama a função que valida o CNPJ
			alert(" Não é um CNPJ válido!" ); 
			return false;			
		}
		alert("É um CNPJ válido!" ); // se quiser mostrar que validou				
		obj.value=maskCNPJ(s);	// se validou o CNPJ mascaramos corretamente
		return true;
	}
}

// função que valida CPF
function validaCPF(s) {
	var c = s.substr(0,9);
	var dv = s.substr(9,2);
	var d1 = 0;
	for (var i=0; i<9; i++) {
		d1 += c.charAt(i)*(10-i);
	}
	if (d1 == 0) return false;
	d1 = 11 - (d1 % 11);
	if (d1 > 9) d1 = 0;
	if (dv.charAt(0) != d1){
		return false;
	}
	d1 *= 2;
	for (var i = 0; i < 9; i++)	{
		d1 += c.charAt(i)*(11-i);
	}
	d1 = 11 - (d1 % 11);
	if (d1 > 9) d1 = 0;
	if (dv.charAt(1) != d1){
		return false;
	}
	return true;
}

// Função que valida CNPJ
function validaCNPJ(CNPJ) {
	var a = new Array();
	var b = new Number;
	var c = [6,5,4,3,2,9,8,7,6,5,4,3,2];
	for (i=0; i<12; i++){
		a[i] = CNPJ.charAt(i);
		b += a[i] * c[i+1];
	}
	if ((x = b % 11) < 2) { a[12] = 0 } else { a[12] = 11-x }
		b = 0;
	for (y=0; y<13; y++) {
		b += (a[y] * c[y]);
	}
	if ((x = b % 11) < 2) { a[13] = 0; } else { a[13] = 11-x; }
	if ((CNPJ.charAt(12) != a[12]) || (CNPJ.charAt(13) != a[13])){
		return false;
	}
	return true;
}

	// Função que permite apenas teclas numéricas
	function soNums(e)
	{
		if (document.all){var evt=event.keyCode;}
		else{var evt = e.charCode;}
		if (evt <20 || (evt >47 && evt<58)){return true;}
		return false;
	}

//	função que mascara o CPF
function maskCPF(CPF){
	return CPF.substring(0,3)+"."+CPF.substring(3,6)+"."+CPF.substring(6,9)+"-"+CPF.substring(9,11);
}

//	função que mascara o CNPJ
function maskCNPJ(CNPJ){
	return CNPJ.substring(0,2)+"."+CNPJ.substring(2,5)+"."+CNPJ.substring(5,8)+"/"+CNPJ.substring(8,12)+"-"+CNPJ.substring(12,14);	
}


//valida telefone
function ValidaTelefone(tel){
	conE = 0;
exp = /\(\d{2}\)\ \d{4}\-\d{4}/
if(!exp.test(tel.value)){
alert('Numero de Telefone Invalido!');
conE +=1;
}else{
		exp.style.display = 'none';
	}
	if(contErro > 0){
		evt.preventDefault();
	}
}

/*adiciona mascara de cep
function MascaraCep(cep){
	if(mascaraInteiro(cep)==false){
		event.returnValue = false;
	} 
	return formataCampo(cep, '00.000-000', event);
}

//valida CEP
function ValidaCep(cep){
	exp = /\d{2}\.\d{3}\-\d{3}/
	if(!exp.test(cep.value))
		alert('Numero de Cep Invalido!'); 

}*/


