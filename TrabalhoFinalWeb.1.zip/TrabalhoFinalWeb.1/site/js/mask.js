
$(function() {
	//data de nascimento, celular, cep
	$('#data_nasc').mask('00/00/0000');
	$('#celular').mask('(00)00000-0000');
	$('#telefone').mask('(00)0000-0000');
	$('#cep').mask('00000-000');

})