<!DOCTYPE html>
<html lang="pt-br">
<head>
	<meta charset="utf-8">
	<title>TECDIAS&nbsp;TELECOMUNICAÇÕES</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<script type="text/javascript" src="js/bootstrap.js"></script>
	<link rel="stylesheet" href="node_modules/bootstrap/compiler/bootstrap.css">
	<link rel="stylesheet" href="node_modules/font-awesome/css/font-awesome.css">
	<link rel="stylesheet" type="text/css" href="stilo.css">
	<script src="https://www.google.com/recaptcha/api.js" async defer></script>
</head>
<body>
	<div class="container"><!-- -fluid  (retirei para teste) -->
		<header>
			<nav id="menunav" class="navbar navbar-expand-lg navbar-light" >
				<div class="container">
					<a href="navbar-brand" href="index.html"><img src="imagens/logo.png" width="200"></a>
					<!--Botão que recolhe a barra de nav-->
					<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSite">
						<span class="navbar-toggler-icon"></span>
					</button>
					<div class="collapse navbar-collapse" id="navbarSite">
						<ul class="navbar-nav ml-auto" >
							<li class="nav-item">
								<a class="nav-link" href="index.html">Home</a>
							</li>
							<li class="nav-item">
								<a class="nav-link" href="empresa.html">Empresa</a>
							</li>
							<li class="nav-item">
								<a class="nav-link" href="cadastro.html">Cadastro</a>
							</li>
							<li class="nav-item">
								<a class="nav-link" href="planos.html">Planos</a>
							</li>
							<li class="nav-item dropdown">
								<a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Atendimento</a>
								<div class="dropdown-menu" aria-labelledby="navbarDropdown">

									<a class="dropdown-item" href="suporte.html">Suporte Técnico</a>
									<a class="dropdown-item" href="centralDoCliente.html">Central do Cliente</a>

								</div>
							</li>

							<li class="nav-item">
								<a class="nav-link" href="contato.html">Contato</a>
							</li>
							<li class="nav-item">
								<a class="nav-link" href="contrato.html">Contrato</a>
							</li>
						</ul>
					</div>
				</div>

			</nav>
			<hr>
		</header>
		<div class="row justify-content-center">
			<div class=" col-8 my-5">
				<div>
					<h3 class="title">Formulário de cadastro</h3>
					<p>Se você deseja adquirir um dos nossos planos ou serviços por favor preencha os campos abaixo com seus dados pessoais e depois clique em <b>ENVIAR CADASTRO</b>.</p>
				</div>
			</div>
		</div>
		<div class="row justify-content-center mb-2">
			<div class="col-sm-8 col-md-6 col-lg-8">
				<div class="form">
					<form action="#" method="post" name="form" id="formCad" onsubmit="validaCadastroP();ValidaCep(form.cep);validaTelefone();" autocomplete="off">
						<h4 class="span1">&nbsp;Informações de acesso e plano</h4>
						<div class="form-row">
							<div class="form-group col-sm-6">
								<div class="1">

									<label class="label" for="venc">Data de Vencimento</label><br>
									<select name="venc" id="venc" class="form-control form-control-sm">
										<option value>Escolha a data</option>
										<option value="01">Todo dia 01</option>
										<option value="05">Todo dia 05</option>
										<option value="10">Todo dia 10</option>
										<option value="15">Todo dia 15</option>
										<option value="20">Todo dia 20</option>
										<option value="25">Todo dia 25</option>
										<option value="30">Todo dia 30</option>
									</select>
									<span class='msgErro msg-venc'></span>
								</div>
							</div>
							<div class="form-group col-sm-6">
								<div class="2">
									<label class="label" form="plano">Escolha seus plano de acesso</label><br>
									<select name="plano" id="plano" class="form-control form-control-sm">
										<option value>Escolha um plano</option>
										<option value="Residencia_10MB"> Residencia_10MB 
											- R$ 70,00 
										</option>
										<option value="Residencia_15MB">  Residencia_15MB 
											- R$ 95,00 
										</option>
										<option value="Residencia_5MB"> Residencia_5MB 
											- R$ 50,00 
										</option>
										<option value="Residencia_2MB"> Residencia_2MB 
											- R$ 30,00 
										</option>
									</select>
									<span class='msgErro msg-plano'></span>

								</div>
							</div>
						</div>
						<div>
							<div class="form-row">
								<div class="form-group col-sm-6">
									<label class="label" form="q">Escolha um login</label><br>
									<input type="text" name="q" id="q" class="form-control form-control-sm" value class="span5" placeholder="login">
									<span class='msgErro msg-log'></span>
								</div>
								<div class="form-group col-sm-6">
									<label class="label" form="senha">Escolha uma senha
										<small>(No mínimo 5 caracteres)</small></label><br>
										<input type="password" name="senha" id="senha" class="form-control form-control-sm" class="senha span4" maxlength="32" placeholder="senha">
										<span class='msgErro msg-senha'></span>
									</div>
								</div>
								<hr class="divide">
								<div class="4">
									<h4 class="span1">Dados do assinante</h4>
									<h5 class="span2">Dados Pessoais</h5>
									<div class="form-row">
										<div class="form-group col-sm-6">
											<label class="label" for="nome">Informe seu nome completo</label><br>
											<input name="nome" id="nome" class="form-control form-control-sm" value="" maxlength="100" type="text">
											<span class='msgErro msg-nome'></span>
										</div>
										<div class="form-group col-sm-6">
											<label class="label" for="email">Informe seu endereço de email</label><br>
											<input name="email" id="email" class="form-control form-control-sm" value=""  maxlength="100" type="text">
											<span class='msgErro msg-email'></span>
										</div>
									</div>
									<div class="form-row">
										<div class="form-group col-sm-4">
											<label class="label" for="cpf_cnpj">CPF/CNPJ <small>(somente números)</small></label><br>
											<input name="cpf_cnpj" id="cpf_cnpj" class="form-control form-control-sm"  maxlength="100" type="text">
											<span class='msgErro msg-cpf'></span>
										</div>
										<!--<div class="form-group col-sm-4">

											<label class="label" for="rg">RG</label><br>
											<input name="rg" id="rg" class="form-control form-control-sm" maxlength="100" value="" type="text">
											<span class='msgErro msg-identidade'></span>
										</div>-->
										<div class="form-group col-sm-4">

											<label class="label" for="cli_data_nasc">Data de nascimento</label><br>
											<input name="nascimento" id="data_nasc" class="form-control form-control-sm" value=""  maxlength="10" type="text">
										</div>
									<!--</div>-->
									<!--<div class="form-row">-->
										<!--<div class="form-group col-sm-4">

											<label class="label" for="telefone">Telefone Fixo 
												<small>(com DDD)</small>
											</label><br>
											<input name="telefone" id="telefone" class="form-control form-control-sm"value="" maxlength="20" type="text"/>
											<span class='msgErro msg-fone'></span>
										</div>-->
										<div class="form-group col-sm-4">

											<label class="label" for="celular">Telefone Celular 
												<small>(com DDD)</small>
											</label><br>
											<input name="celular" id="celular" class="form-control form-control-sm" value="" maxlength="20" type="text">
											<span class='msgErro msg-celular'></span>
										</div>
										<!--<div class="form-group col-sm-4">
											<label class="label" for="promocod">Cód. promocional 
												<small>(Se possuir)</small><br>
											</label><br>
											<input name="promocod" id="promocod" class="form-control form-control-sm" value="" maxlength="50" type="text">
										</div>-->
									</div>

									<h5 class="span2">Endereço</h5>
									<div class="form-row">
										<div class="form-group col-sm-6">
											<label class="label" for="cep">Informe o CEP 
												<small>(Ex. xxxxx-xxx)</small>
											</label><br>
											<input name="cep" type="text" value="" id="cep" class="form-control form-control-sm" maxlength="9">
											<span class='msgErro msg-cep'></span>
										</div>
										<div class="form-group col-sm-6">
											<label class="label" for="endereco">Logradouro 
												<small>(Rua, Avenida, Travessa, etc)</small>
											</label><br>
											<input name="endereco" id="endereco" class="form-control form-control-sm" value="" maxlength="100" type="text">
											<span class='msgErro msg-endereco'></span>
										</div>
									</div>
									<div class="form-row">
										<div class="form-group col-sm-4">
											<label class="label" for="numero">Nº</label><br>
											<input name="numero" type="text" value="" id="numero" class="form-control form-control-sm" maxlength="10" class="span2">
											<span class='msgErro msg-numCasa'></span>
										</div>
										<div class="form-group col-sm-4">
											<label class="label label-info" for="complemento"> Complem. <small>(Andar, Bloco, Lote, etc)</small></label><br>
											<input name="complemento" id="complemento" class="form-control form-control-sm" value=""  maxlength="70" type="text"> 
										</div>
										<div class="form-group col-sm-4">
											<label class="label" for="bairro">Bairro</label><br>
											<input name="bairro" id="bairro" class="form-control form-control-sm" value="" maxlength="100" type="text">
											<span class='msgErro msg-bairro'></span>
										</div>
									</div>
									<div class="form-row">
										<div class="form-group col-sm-6">
											<label class="label" for="cidade">Cidade / Província / Vilarejo</label><br>
											<input name="cidade" id="cidade" class="form-control form-control-sm" value="" maxlength="100" type="text" >
											<span class='msgErro msg-cidade'></span>
										</div>
										<div class="form-group col-sm-6">
											<label class="label" for="estado">Estado 
												<small>UF</small>
											</label><br>
											<select name="estado" size="1" id="estado"  class="form-control form-control-sm">
												<option value="AC">Acre</option>
												<option value="AL">Alagoas</option>
												<option value="AP">Amapá</option>
												<option value="AM">Amazonas</option>
												<option value="BA">Bahia</option>
												<option value="CE">Ceará</option>
												<option value="DF">Distrito Federal</option>
												<option value="ES">Espírito Santo</option>
												<option value="GO">Goiás</option>
												<option value="MA">Maranhão</option>
												<option value="MT">Mato Grosso</option>
												<option value="MS">Mato Grosso do Sul</option>
												<option value="MG" selected="selected">Minas Gerais</option>
												<option value="PA">Pará</option>
												<option value="PB">Paraíba</option>
												<option value="PR">Paraná</option>
												<option value="PE">Pernambuco</option>
												<option value="PI">Piauí</option>
												<option value="RJ">Rio de Janeiro</option>
												<option value="RN">Rio Grande do Norte</option>
												<option value="RS">Rio Grande do Sul</option>
												<option value="RO">Rondônia</option>
												<option value="RR">Roraima</option>
												<option value="SC">Santa Catarina</option>
												<option value="SP">São Paulo</option>
												<option value="SE">Sergipe</option>
												<option value="TO">Tocantins</option>
											</select>
											<span class='msgErro msg-estado'></span>
										</div>
									</div>
								</div>
								<hr class="divide">
								<div>
									<h4 class="span1">&nbsp;Verificação</h4>
									<div class="g-recaptcha" data-sitekey="6Ldxvb8UAAAAAAy07gD2xh_GGfey9DkCP7_Cl--b"></div>
								</div>
								<hr class="divide">
								<div>
									<h4 class="span1">&nbsp;Termos e condições de uso</h4>
								</div>
								<div class="form-row">
									<div class="form-group col-sm-5">
										<div class="span9">
											<label for="aceitou" class="form-check-label">
												<input type="checkbox" name="aceitouT" id="aceitou" class="form-check-input" value="sim">
												Declaro que li e aceito o <strong><a href="contrato.php">contrato</a></strong> do provedor.
												<span class='msgErro msg-termo'></span>
											</label>
										</div>
									</div>
								</div>
								<div class="span9">
									<div class="form-row">
										<div class="form-group col-sm-9">
											<div class="span3">
												<button id="enviar" type="submit" class="btn btn-large btn-primary" name="enviar"><i class="iconxternal-link-sign"></i>&nbsp;ENVIAR CADASTRO</button>
											</div>
										</div>
										<div class="span3 pull-right">
											<div class="form-group col-sm-5">
												<div class=text-right>
													<button type="reset" id="limpar" class="btn btn-danger btn-large" value="LIMPAR FORMULÁRIO" name="limpar"><i class="icon-eraer"></i>&nbsp;LIMPAR CAMPOS</button>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
						</form>
						<hr>
					</div>
				</div>
			</div>
		</div>


		<footer class="page-footer font-small blue-grey lighten-5" style="background-color:#1C1C1C;">
			<!-- Footer Links -->
			<div  id="rodape" class="pt-1" >
				<div class="container rod text-center text-md-left mt-5">
					<div class="row mt-4">
						<div id="rp" class="col-md-4 col-lg-4 col-xl-4 mb-1">
							<h6 class="text-uppercase font-weight-bold">TECDIAS &nbsp; TELECOMUNICACÕES</h6>
							<hr class="teal accent-3 mb-4 mt-0 d-inline-block mx-auto" style="width: 220px;">
							<p><img src="imagens/wifiWhite.png">Provedor de acesso a internet</p>
							<img src="imagens/anatel.png" class="img-fluid" width="300">

						</div>
						<div id="rc" class="col-md-5 col-lg-3 col-xl-3 mx-auto md-5 ">

							<h6 class="text-uppercase font-weight-bold">Contato</h6>
							<hr class="teal accent-3 mb-4 mt-0 d-inline-block mx-auto" style="width: 60px;">
							<p><img src="imagens/localWhite.png">Fruta de Leite-MG <br>
								<img src="imagens/mailWhite.png"><a href="mailto:atendimento@tecdias.com.br"> atendimento@tecdias.com.br</a><br>
								<img src="imagens/phoneWhite.png">(38)9960-8910 <br>
								<a class="centralR" href="centralDoCliente.html"><img src="imagens/pessoaWhite.png">Acessar a Central</a><br></p>

							</div>

							<div id="rl" class="col-md-4 col-lg-2 col-xl-2 mx-auto mb-1">

								<h6 class="text-uppercase font-weight-bold">Localização</h6>
								<hr class="teal accent-3 mb-4 mt-0 d-inline-block mx-auto" style="width: 60px;">
								<div id="map-container" class="z-depth-1-half map-container">
									<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d13116.176932536202!2d-42.53672772812969!3d-16.115328807033503!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x74df5832acfc0f5%3A0x9c3f7d179ef36c39!2sFruta%20de%20Leite%2C%20MG%2C%2039558-000!5e1!3m2!1spt-BR!2sbr!4v1571247261661!5m2!1spt-BR!2sbr" width="300" height="200" frameborder="0" style="border:0;" allowfullscreen=""></iframe>
								</div>
							</div>
						</div>
					</div>
				</div>

				<div id="rodapeF" class="footer-copyright text-center text-black-50 py-3"><p>© 2019 - Todos os direitos reservados - <a class="central" href="">TECDIAS&nbsp;TELECOMUNICACÕES</a></p>
				</div>
		</footer>
	<script src="node_modules/jquery/dist/jquery.js"></script>
	<script src="node_modules/popper.js/dist/umd/popper.js"></script>
	<script src="node_modules/bootstrap/dist/js/bootstrap.js"></script>
	<script type="text/javascript" src="js/scriptCad.js"></script>
	<script type="text/javascript" src="pluguins/jquery.mask.js"></script>
	<script type="text/javascript" src="js/mask.js"></script>

</body>
</html>